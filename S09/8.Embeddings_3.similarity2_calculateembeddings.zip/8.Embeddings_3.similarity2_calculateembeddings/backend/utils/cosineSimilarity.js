

const cosineSimilarity = (vector1, vector2) => {

    return 1;
}
module.exports = cosineSimilarity;