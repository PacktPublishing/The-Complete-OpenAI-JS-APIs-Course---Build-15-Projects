import React, { useState } from 'react';
import '../style/style.css';

function TranscribeSpeech() {

}

export default TranscribeSpeech;
