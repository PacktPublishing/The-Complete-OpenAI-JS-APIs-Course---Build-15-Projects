import React, { useState } from 'react';
import '../style/style.css';

function TranslateAudio() {

}

export default TranslateAudio;
